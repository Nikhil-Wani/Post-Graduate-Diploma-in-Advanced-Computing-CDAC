package training.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import training.demo.model.Person;
import training.demo.service.PersonService;
@CrossOrigin(maxAge = 4800,allowCredentials = "false",methods= {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
@RestController
public class PersonController {
	@Autowired
	PersonService personService;
	
	@RequestMapping(value="/persons",method=RequestMethod.GET,produces="application/json")
	public List<Person> getallPerson(){
		return personService.getAllPerson();
		   
	}
	
	@RequestMapping(value="/persons",method=RequestMethod.POST,consumes="application/json")
	public List<Person> addPerson(@RequestBody Person p){
		personService.addPerson(p);
		return personService.getAllPerson();
	}
	
	@RequestMapping(value="/persons",method=RequestMethod.PUT,consumes="application/json")
	public List<Person> updatePerson(@RequestBody Person p){
		personService.updatePerson(p);
		return personService.getAllPerson();
		
		
	}
	
	
	
	

}
